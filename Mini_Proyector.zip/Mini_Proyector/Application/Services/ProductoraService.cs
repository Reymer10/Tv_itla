﻿using Application.Repository;
using Application.ViewModel.Genero;
using Application.ViewModel.Productora;
using DataBase;
using DataBase.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Services
{
    public class ProductoraService
    {
        private readonly ProductoraRepository _productoraRepository;

        public ProductoraService(ApplicationContext context)
        {
            _productoraRepository = new(context);
        }
        public async Task Update(ProductoraSaveViewModel vm)
        {
            Productora productora = new();
            productora.Id = vm.Id;
            productora.Name = vm.Name;

            await _productoraRepository.Update(productora);
        }
        public async Task Add(ProductoraSaveViewModel vm)
        {
            Productora productora = new();
            productora.Id = vm.Id;
            productora.Name = vm.Name;

            await _productoraRepository.AddAsync(productora);


        }
        public async Task<ProductoraSaveViewModel> GetByIdSaveViewModel(int id)
        {
            var productora = await _productoraRepository.GetByIdAsync(id);
            ProductoraSaveViewModel vm = new();
            vm.Id = productora.Id;
            vm.Name = productora.Name;

            return vm;
        }
        public async Task<List<ProductoraViewModel>> GetAllViewModel()
        {
            var productora = await _productoraRepository.GetAllAsync();
            return productora.Select(x => new ProductoraViewModel
            {
                Id = x.Id,
                Name = x.Name,
            }).ToList();
        }

        public async Task Delete(int id)
        {
            var productora = await _productoraRepository.GetByIdAsync(id);
            await _productoraRepository.DeleteAsync(productora);
        }
    }
}
