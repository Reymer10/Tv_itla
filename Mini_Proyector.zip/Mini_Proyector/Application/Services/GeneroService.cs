﻿using Application.Repository;
using Application.ViewModel.Genero;
using DataBase;
using DataBase.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Services
{
    public class GeneroService
    {
        private readonly GeneroRepository _generoRepository;

        public GeneroService(ApplicationContext context)
        {
            _generoRepository = new(context);
        }
        public async Task Update(GeneroSaveViewModel vm)
        {
            Genero genero = new();
            genero.Id = vm.Id;
            genero.Name = vm.Name;

            await _generoRepository.Update(genero);
        }
        public async Task Add(GeneroSaveViewModel vm)
        {
            Genero genero = new();
            genero.Id = vm.Id;
            genero.Name = vm.Name;

            await _generoRepository.AddAsync(genero);


        }
        public async Task<GeneroSaveViewModel> GetByIdSaveViewModel(int id)
        {
            var genero = await _generoRepository.GetByIdAsync(id);
            GeneroSaveViewModel vm = new();
            vm.Id = genero.Id;
            vm.Name = genero.Name;

            return vm;
        }
        public async Task<List<GeneroViewModel>> GetAllViewModel()
        {
            var genero = await _generoRepository.GetAllAsync();
            return genero.Select(x => new GeneroViewModel
            {
                Id = x.Id,
                Name = x.Name,
            }).ToList();
        }

        public async Task Delete(int id)
        {
            var genero = await _generoRepository.GetByIdAsync(id);
            await _generoRepository.DeleteAsync(genero);
        }
    }
}
