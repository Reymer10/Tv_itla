﻿using Application.Repository;
using Application.ViewModel.Serie;
using DataBase;
using DataBase.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Services
{
    public class SerieService
    {
        private readonly SerieRepository _serieRepository;

        public SerieService(ApplicationContext context)
        {
            _serieRepository = new(context);
        }
        public async Task Update(SerieSaveViewModel vm)
        {
            Serie serie = new();
            serie.Id = vm.Id;
            serie.Name = vm.Name;
            serie.UrlVideo = vm.UrlVideo;
            serie.Image = vm.Image;
            serie.GeneroPrimarioId = vm.GeneroPrimarioId;
            serie.GeneroSecundarioId = vm.GeneroSecundarioId;
            serie.ProductoraId = vm.ProductoraId;


            await _serieRepository.Update(serie);
        }
        public async Task Add(SerieSaveViewModel vm)
        {
            Serie serie = new();
            serie.Id = vm.Id;
            serie.Name = vm.Name;
            serie.UrlVideo = vm.UrlVideo;
            serie.Image = vm.Image;
            serie.GeneroPrimarioId = vm.GeneroPrimarioId;
            serie.GeneroSecundarioId = vm.GeneroSecundarioId;
            serie.ProductoraId = vm.ProductoraId;

            await _serieRepository.AddAsync(serie);


        }
        public async Task<SerieSaveViewModel> GetByIdSaveViewModel(int id)
        {
            var serie = await _serieRepository.GetByIdAsync(id);
            SerieSaveViewModel vm = new();
            vm.Id = serie.Id;
            vm.Name = serie.Name;
            vm.UrlVideo = serie.UrlVideo;
            vm.Image = serie.Image;
            vm.GeneroPrimarioId = serie.GeneroPrimarioId;
            vm.GeneroSecundarioId = serie.GeneroSecundarioId;
            vm.ProductoraId = serie.ProductoraId;


            return vm;
        }

        public async Task<List<SerieViewModel>> GetAllWithFilters(int producterId, int generoId)
        {
            var series = await _serieRepository.GetAllAsyncInclude(new List<string> { "genero", "productora", "generoSecundario" });
            var list = series.Select(x => new SerieViewModel
            {
                Id = x.Id,
                Name = x.Name,
                UrlVideo = x.UrlVideo,
                Image = x.Image,
                GeneroPrimarioId = x.GeneroPrimarioId,
                GeneroSecundarioId = x.GeneroSecundarioId,
                ProductoraId = x.ProductoraId,
                GeneroNamePrimario = x.genero.Name,
                GeneroNameSecundario = x.generoSecundario?.Name,
                ProductoraName = x.productora.Name
            }).ToList();

            if (producterId != 0)
            {
                list = list.Where(s => s.ProductoraId == producterId).ToList();
            }
            else if (generoId != 0)
            {
                list = list.Where(s => s.GeneroPrimarioId == generoId || s.GeneroSecundarioId == generoId).ToList();
            }

            return list.ToList();
        }

        public async Task<List<SerieViewModel>> SearchAsync(string name)
        {
            var series = await _serieRepository.GetAllAsyncInclude(new List<string> { "genero", "productora", "generoSecundario" });
            var list = series.Select(x => new SerieViewModel
            {
                Id = x.Id,
                Name = x.Name,
                UrlVideo = x.UrlVideo,
                Image = x.Image,
                GeneroPrimarioId = x.GeneroPrimarioId,
                GeneroSecundarioId = x.GeneroSecundarioId,
                ProductoraId = x.ProductoraId,
                GeneroNamePrimario = x.genero.Name,
                GeneroNameSecundario = x.generoSecundario?.Name,
                ProductoraName = x.productora.Name
            }).ToList();

            if (name != null)
            {
                list = list.Where(s=>s.Name.Contains(name)).ToList();
            }

            return list.ToList();
        }
        public async Task<List<SerieViewModel>> GetAllViewModel()
        {
            var series = await _serieRepository.GetAllAsyncInclude(new List<string> { "genero", "productora", "generoSecundario" });
            return series.Select(x => new SerieViewModel
            {
                Id = x.Id,
                Name = x.Name,
                UrlVideo = x.UrlVideo,
                Image = x.Image,
                GeneroPrimarioId = x.GeneroPrimarioId,
                GeneroSecundarioId = x.GeneroSecundarioId,
                ProductoraId = x.ProductoraId,
                GeneroNamePrimario = x.genero.Name,
                GeneroNameSecundario = x.generoSecundario?.Name,
                ProductoraName = x.productora.Name
            }).ToList();
        }

        public async Task Delete(int id)
        {
            var serie = await _serieRepository.GetByIdAsync(id);
            await _serieRepository.DeleteAsync(serie);
        }
    }
}
