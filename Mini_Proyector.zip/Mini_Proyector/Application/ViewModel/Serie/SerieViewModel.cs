﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.ViewModel.Serie
{
    public class SerieViewModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string UrlVideo { get; set; }
        public string Image { get; set; }
        public string GeneroNamePrimario { get; set; }
        public string? GeneroNameSecundario { get; set; }
        public string ProductoraName { get; set; }
        public int GeneroPrimarioId { get; set; }
        public int? GeneroSecundarioId { get; set; }
        public int ProductoraId { get; set; }
    }
}
