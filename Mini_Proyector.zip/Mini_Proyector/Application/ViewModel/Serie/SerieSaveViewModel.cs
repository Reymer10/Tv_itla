﻿using Application.ViewModel.Genero;
using Application.ViewModel.Productora;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.ViewModel.Serie
{
    public class SerieSaveViewModel
    {
        public int Id { get; set; }
        [Required(ErrorMessage ="Inserte el nombre")]
        public string Name { get; set; }
        [Required(ErrorMessage = "Inserte el video")]
        public string UrlVideo { get; set; }
        [Required(ErrorMessage = "Inserte la imagen")]
        public string Image { get; set; }
        [Required(ErrorMessage = "Inserte el genero primario")]
        public int GeneroPrimarioId { get; set; }

        public int? GeneroSecundarioId { get; set; }
        [Required(ErrorMessage = "Inserte la productora")]
        public int ProductoraId { get; set; }
        [NotMapped]
        public List<GeneroViewModel>? generos { get; set; }
        [NotMapped]
        public List<ProductoraViewModel>? productoras { get; set; }
    }
}
