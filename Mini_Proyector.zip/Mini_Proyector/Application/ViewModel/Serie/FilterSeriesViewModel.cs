﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.ViewModel.Serie
{
    public class FilterSeriesViewModel
    {
        public string Name { get; set; }
    }
}
