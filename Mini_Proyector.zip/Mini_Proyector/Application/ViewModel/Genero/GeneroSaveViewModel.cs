﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.ViewModel.Genero
{
    public class GeneroSaveViewModel
    {
        public int Id { get; set; }
        [Required(ErrorMessage ="Inserte el nombre")]
        public string Name { get; set; }
    }
}
