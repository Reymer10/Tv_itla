﻿using DataBase;
using DataBase.Models;
using Microsoft.EntityFrameworkCore;

namespace Application.Repository
{
    public class SerieRepository
    {
        private readonly ApplicationContext _context;
        public SerieRepository(ApplicationContext context)
        {
            _context = context;
        }
        public async Task AddAsync(Serie serie)
        {
            await _context.series.AddAsync(serie);
            await _context.SaveChangesAsync();
        }
        public async Task Update(Serie serie)
        {
            _context.Entry(serie).State = EntityState.Modified;
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(Serie Serie)
        {
            _context.Set<Serie>().Remove(Serie);
            await _context.SaveChangesAsync();
        }

        public async Task<List<Serie>> GetAllAsync()
        {
            return await _context.Set<Serie>().ToListAsync();
        }
        public async Task<List<Serie>> GetAllAsyncInclude(List<string> properties)
        {
            var query = _context.Set<Serie>().AsQueryable();
            foreach (var item in properties)
            {
                query = query.Include(item);
            }
            return await query.ToListAsync();
        }
        public async Task<Serie> GetByIdAsync(int Id)
        {
            return await _context.Set<Serie>().FindAsync(Id);
        }
        public async Task<Serie> GetByNameAsync(string nombre)
        {
            return await _context.Set<Serie>().FindAsync(nombre);
        }
    }
}
