﻿using DataBase;
using DataBase.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Repository
{
    public class GeneroRepository
    {
        private readonly ApplicationContext _context;
        public GeneroRepository(ApplicationContext context)
        {
            _context = context;
        }
        public async Task AddAsync(Genero genero)
        {
            await _context.generos.AddAsync(genero);
            await _context.SaveChangesAsync();
        }
        public async Task Update(Genero genero)
        {
            _context.Entry(genero).State = EntityState.Modified;
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(Genero genero)
        {
            _context.Set<Genero>().Remove(genero);
            await _context.SaveChangesAsync();
        }

        public async Task<List<Genero>> GetAllAsync()
        {
            return await _context.Set<Genero>().ToListAsync();
        }
        public async Task<Genero> GetByIdAsync(int Id)
        {
            return await _context.Set<Genero>().FindAsync(Id);
        }
        public async Task<Genero> GetByNameAsync(string nombre)
        {
            return await _context.Set<Genero>().FindAsync(nombre);
        }
    }
}
