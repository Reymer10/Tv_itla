﻿using DataBase;
using DataBase.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Repository
{
    public class ProductoraRepository
    {
        private readonly ApplicationContext _context;
        public ProductoraRepository(ApplicationContext context)
        {
            _context = context;
        }
        public async Task AddAsync(Productora productora)
        {
            await _context.productoras.AddAsync(productora);
            await _context.SaveChangesAsync();
        }
        public async Task Update(Productora productora)
        {
            _context.Entry(productora).State = EntityState.Modified;
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(Productora productora)
        {
            _context.Set<Productora>().Remove(productora);
            await _context.SaveChangesAsync();
        }

        public async Task<List<Productora>> GetAllAsync()
        {
            return await _context.Set<Productora>().ToListAsync();
        }
        public async Task<Productora> GetByIdAsync(int Id)
        {
            return await _context.Set<Productora>().FindAsync(Id);
        }
        public async Task<Productora> GetByNameAsync(string nombre)
        {
            return await _context.Set<Productora>().FindAsync(nombre);
        }
    }
}
