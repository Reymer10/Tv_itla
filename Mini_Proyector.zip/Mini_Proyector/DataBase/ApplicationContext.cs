﻿using DataBase.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataBase
{
    public class ApplicationContext : DbContext 
    {
       public ApplicationContext(DbContextOptions<ApplicationContext> options)  : base(options) { }
        
        public DbSet<Productora> productoras { get; set; }   
        public DbSet<Genero> generos { get; set; }
        public DbSet<Serie> series { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //FLUENT API

            #region tables 
            modelBuilder.Entity<Productora>()
                .ToTable("Productora");
            modelBuilder.Entity<Genero>()
                .ToTable("Genero");
            modelBuilder.Entity<Serie>()
                .ToTable("Serie");
            #endregion


            #region "Primary Keys"
            modelBuilder.Entity<Productora>()
                .HasKey(p => p.Id);
            modelBuilder.Entity<Genero>()
                .HasKey(g => g.Id);
            modelBuilder.Entity<Serie>()
                .HasKey(s => s.Id);
            #endregion

            #region "Relationships"
            modelBuilder.Entity<Productora>()
                .HasMany<Serie>(p => p.series)
                .WithOne(p=> p.productora)
                .HasForeignKey(s=>s.ProductoraId)
                .OnDelete(DeleteBehavior.Cascade);
            modelBuilder.Entity<Genero>()
                .HasMany<Serie>(p => p.series)
                .WithOne(p => p.genero)
                .HasForeignKey(s => s.GeneroPrimarioId)
                .OnDelete(DeleteBehavior.Cascade);
            modelBuilder.Entity<Serie>()
                .HasOne<Genero>(p => p.generoSecundario)
                .WithMany()
                .HasForeignKey(s => s.GeneroSecundarioId)
                .IsRequired(false);
            #endregion

            #region "Property Configurations"
            #region productora
            modelBuilder.Entity<Productora>()
                .Property(p => p.Name)
                .IsRequired();
            #endregion

            #region genero
            modelBuilder.Entity<Genero>()
                .Property(g => g.Name)
                .IsRequired();

            #endregion
            #region serie
            modelBuilder.Entity<Serie>(g =>
            {
                g.Property(g => g.Name).HasMaxLength(100).IsRequired();
                g.Property(g => g.UrlVideo).IsRequired();
                g.Property(g => g.Image).IsRequired();

            });
            #endregion
            #endregion
        }

    }
}
