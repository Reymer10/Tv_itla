﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataBase.Models
{
    public class Serie
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string UrlVideo { get; set; }
        public string Image { get; set; }
        public int GeneroPrimarioId { get; set; }
        public int? GeneroSecundarioId { get; set; }
        public int ProductoraId { get; set; }
        public Genero genero { get; set; }
        public Genero generoSecundario { get; set; }
        public Productora productora { get; set; }


    }
}
