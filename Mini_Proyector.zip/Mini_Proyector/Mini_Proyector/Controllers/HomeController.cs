using Application.Services;
using Application.ViewModel.Serie;
using DataBase;
using Microsoft.AspNetCore.Mvc;
using Mini_Proyector.Models;
using System.Diagnostics;

namespace Mini_Proyector.Controllers
{
    public class HomeController : Controller
    {
        private readonly SerieService _serieServices;
        private readonly GeneroService _generoServices;
        private readonly ProductoraService _productoraServices;

        public HomeController(ApplicationContext context)
        {
            _serieServices = new(context);
            _generoServices = new(context);
            _productoraServices = new(context);
        }

        public async Task<IActionResult> Index(int productoraId, int generoId, string? nombreSerie)
        {
            ViewBag.Generos = await _generoServices.GetAllViewModel();
            ViewBag.Productoras = await _productoraServices.GetAllViewModel();
            List<SerieViewModel> vm = await _serieServices.GetAllViewModel();
            if (productoraId != 0 || generoId != 0)
            {
                vm = await _serieServices.GetAllWithFilters(productoraId, generoId);
            }
            else if(nombreSerie != null)
            {
               vm = await _serieServices.SearchAsync(nombreSerie);
            }
            return View(vm);
        }

        public async Task<IActionResult> Detail(int id)
        {
            var serie = await _serieServices.GetByIdSaveViewModel(id);

            if (serie.UrlVideo.Contains("www.youtube.com"))
            {
                serie.UrlVideo = serie.UrlVideo.Replace("watch?v=", "embed/");
            }
            else if (serie.UrlVideo.Contains("youtu.be"))
            {
                serie.UrlVideo = serie.UrlVideo.Replace("youtu.be/", "www.youtube.com/embed/");
            }
            return View(serie);
        }
    }
}
