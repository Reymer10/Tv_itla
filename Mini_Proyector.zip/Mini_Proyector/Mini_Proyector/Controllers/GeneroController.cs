﻿using Application.Services;
using Application.ViewModel.Genero;
using Application.ViewModel.Serie;
using DataBase;
using Microsoft.AspNetCore.Mvc;

namespace Mini_Proyector.Controllers
{
    public class GeneroController : Controller
    {
        private readonly GeneroService _generoServices;
        public GeneroController(ApplicationContext context)
        {
            _generoServices = new(context);
        }

        public async Task<IActionResult> Index()
        {
            return View(await _generoServices.GetAllViewModel());
        }

        public IActionResult Create()
        {
            return View("Create", new GeneroSaveViewModel());
        }
        [HttpPost]
        public async Task<IActionResult> Create(GeneroSaveViewModel vm)
        {
            if (!ModelState.IsValid)
            {
                return View("Create", vm);
            }
            await _generoServices.Add(vm);
            return RedirectToRoute(new { controller = "Genero", action = "Index" });
        }
        public async Task<IActionResult> Edit(int id)
        {
            return View("Create", await _generoServices.GetByIdSaveViewModel(id));
        }
        [HttpPost]
        public async Task<IActionResult> Edit(GeneroSaveViewModel vm)
        {
            if (!ModelState.IsValid)
            {
                return View("Create", vm);
            }
            await _generoServices.Update(vm);
            return RedirectToRoute(new { controller = "Genero", action = "Index" });
        }

        public async Task<IActionResult> Delete(int id)
        {
            return View("Delete", await _generoServices.GetByIdSaveViewModel(id));
        }

        [HttpPost]
        public async Task<IActionResult> DeletePost(int id)
        {
            await _generoServices.Delete(id);
            return RedirectToRoute(new { controller = "Genero", action = "Index" });
        }
    }
}
