﻿using Application.Services;
using Application.ViewModel.Productora;
using Application.ViewModel.Serie;
using DataBase;
using Microsoft.AspNetCore.Mvc;

namespace Mini_Proyector.Controllers
{
    public class ProductoraController : Controller
    {
        private readonly ProductoraService _productoraServices;
        public ProductoraController(ApplicationContext context)
        {
            _productoraServices = new(context);
        }

        public async Task<IActionResult> Index()
        {
            return View(await _productoraServices.GetAllViewModel());
        }

        public IActionResult Create()
        {
            return View("Create", new ProductoraSaveViewModel());
        }
        [HttpPost]
        public async Task<IActionResult> Create(ProductoraSaveViewModel vm)
        {
            if (!ModelState.IsValid)
            {
                return View("Create", vm);
            }
            await _productoraServices.Add(vm);
            return RedirectToRoute(new { controller = "Productora", action = "Index" });
        }
        public async Task<IActionResult> Edit(int id)
        {
            return View("Create", await _productoraServices.GetByIdSaveViewModel(id));
        }
        [HttpPost]
        public async Task<IActionResult> Edit(ProductoraSaveViewModel vm)
        {
            if (!ModelState.IsValid)
            {
                return View("Create", vm);
            }
            await _productoraServices.Update(vm);
            return RedirectToRoute(new { controller = "Productora", action = "Index" });
        }

        public async Task<IActionResult> Delete(int id)
        {
            return View("Delete", await _productoraServices.GetByIdSaveViewModel(id));
        }

        [HttpPost]
        public async Task<IActionResult> DeletePost(int id)
        {
            await _productoraServices.Delete(id);
            return RedirectToRoute(new { controller = "Productora", action = "Index" });
        }
    }
}
