﻿using Application.Services;
using Application.ViewModel.Serie;
using DataBase;
using Microsoft.AspNetCore.Mvc;

namespace Mini_Proyector.Controllers
{
    public class SerieController : Controller
    {
        private readonly SerieService _serieServices;
        private readonly GeneroService _generoServices;
        private readonly ProductoraService _productoraServices;
        public SerieController(ApplicationContext context)
        {
            _serieServices = new(context);
            _generoServices = new(context);
            _productoraServices = new(context);
        }

        public async Task<IActionResult> Index()
        {
            return View(await _serieServices.GetAllViewModel());
        }

        public async Task<IActionResult> Create()
        {
            SerieSaveViewModel vm = new();
            vm.generos = await _generoServices.GetAllViewModel();
            vm.productoras = await _productoraServices.GetAllViewModel();
            return View("Create", vm);
        }
        [HttpPost]
        public async Task<IActionResult> Create(SerieSaveViewModel vm)
        {
            if (!ModelState.IsValid)
            {
                vm.generos = await _generoServices.GetAllViewModel();
                vm.productoras = await _productoraServices.GetAllViewModel();
                return View("Create", vm);
            }
            await _serieServices.Add(vm);
            return RedirectToRoute(new { controller = "Serie", action = "Index" });
        }
        public async Task<IActionResult> Edit(int id)
        {
            SerieSaveViewModel vm = await _serieServices.GetByIdSaveViewModel(id);
            vm.generos = await _generoServices.GetAllViewModel();
            vm.productoras = await _productoraServices.GetAllViewModel();
            return View("Create", vm);
        }
        [HttpPost]
        public async Task<IActionResult> Edit(SerieSaveViewModel vm)
        {
            if (!ModelState.IsValid)
            {
                vm.generos = await _generoServices.GetAllViewModel();
                vm.productoras = await _productoraServices.GetAllViewModel();
                return View("Create", vm);
            }
            await _serieServices.Update(vm);
            return RedirectToRoute(new { controller = "Serie", action = "Index" });
        }

        public async Task<IActionResult> Delete(int id)
        {
            return View("Delete", await _serieServices.GetByIdSaveViewModel(id));
        }

        [HttpPost]
        public async Task<IActionResult> DeletePost(int id)
        {
            await _serieServices.Delete(id);
            return RedirectToRoute(new { controller = "Serie", action = "Index" });
        }
    }
}
